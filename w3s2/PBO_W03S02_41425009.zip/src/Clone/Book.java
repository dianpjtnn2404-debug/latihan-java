/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Clone;

/**
 *
 * @author dianp
 */
public class Book implements Cloneable{
    private String t;
    public book(String t) {
        this.t = t;
    }
    
    @Override
    public Object clone() throws CloneNotSupportedException {
        return super.clone();
    }
    
    public String getTitle() {
        return t
    }
    
}
