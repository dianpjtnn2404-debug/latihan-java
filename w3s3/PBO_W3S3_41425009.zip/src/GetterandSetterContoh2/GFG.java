/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package GetterandSetterContoh2;

/**
 *
 * @author dianp
 */
public class GFG {
    public static void main(String[] args)
    {
        GetSet obj = new GetSet();
        obj.setNumber(5);
        System.out.println(obj.getNumber());
    }
}
