/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package PassingObject;

/**
 *
 * @author dianp
 */
public class ObjectPassDemo {
    int a, b;
    
    ObjectPassDemo (int i, int j)
    {
        a = i;
        b = j;
    }
    
    boolean equalTo (ObjectPassDemo o)
    {
        return (o.a == a && o.b == b);
    }
}
