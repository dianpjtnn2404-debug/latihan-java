/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package parameterized;

/**
 *
 * @author dianp
 */
public class Main {
    public static void main (String[] args)
    {
        Geeks geek1 = new Geeks("Sweta", 68);
        System.out.println("GeeksName: " + geek1.name + "and GeekId: " + geek1.id);
    }
}
